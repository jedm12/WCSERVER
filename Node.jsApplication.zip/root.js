module.exports = function(name) {
    var words1 = 'Welcome';
    var words2 = 'This is an activity about basics of Nodes.js'
      return words1 + ' ' + name + ' ' + words2;
    }

/*Name: Jed Miguel O. Bartolome
  Time: 02/02/2022
  Section: WD-201
*/