module.exports = function(name) {
    var words1 = 'if you want additional details about this activity go to this site:';
    var words2 = 'https://www.tutorialsteacher.com/nodejs/nodes-tutorials'
      return name + ' ' + words1 +' ' + words2;
    }

/*Name: Jed Miguel O. Bartolome
Time: 02/02/2022
Section: WD-201
*/