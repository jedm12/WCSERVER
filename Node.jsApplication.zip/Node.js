var http = require('http'); // Import Node.js core module
var root = require('./root.js')
var about = require('./about.js')
var contact = require('./contact.js')
var username = 'John Smith';

var server = http.createServer(function(req,res){

    //set response header
    if (req.url == '/'){
        res.writeHead(200, {'Content-Type' : 'text/html'});

        res.write('<html><body> <h1> This is home page. </h1></body></html>');
        res.write(root(username));
        res.end();


    }else if (req.url == "/about"){

        res.writeHead(200, {'Content-Type' : 'text/html'});
        res.write('<html><body> <h1> This is the About Page. </h1> </body></html>')
        res.write(about(username));
        res.end();
        
    }
    else if (req.url == "/contact"){

        res.writeHead(200, {'Content-Type' : 'text/html'});
        res.write('<html><body> <h1> This is is the Contact Page. </h1> </body></html>')
        res.write(contact(username));
        res.end();
        
    }
    else if (req.url == "/gallery"){

        res.writeHead(200, {'Content-Type' : 'text/html'});
        res.write('<html><body> <h1> This is is the Gallery Page. </h1> </body></html>')
        res.end();
        
    }
    else
        res.end('<html> <body> <p> <strong> Invalid Request! </strong> </p> </body> </html>')
    

});

server.listen(1400);
console.log('NodeJS localhost at port 1400 is running... ')

/*Name: Jed Miguel O. Bartolome
  Time: 02/02/2022
  Section: WD-201
*/