module.exports = function(name) {
    var words1 = 'Hello';
    var words2 = 'This activity will teach you on how to deal with a simple server and local modules in Node.js'
      return words1 + ' ' + name + '. ' + words2;
    }

/*Name: Jed Miguel O. Bartolome
Time: 02/02/2022
Section: WD-201
*/